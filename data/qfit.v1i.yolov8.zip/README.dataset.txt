# qfit > 2024-12-29 12:21am
https://universe.roboflow.com/qfit/qfit

Provided by a Roboflow user
License: CC BY 4.0

